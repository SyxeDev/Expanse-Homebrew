export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "systems/ExpanseHomebrew/templates"
    ];
    return loadTemplates(templatePaths);
};
